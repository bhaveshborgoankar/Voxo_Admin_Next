import { createContext } from 'react';

const CreateContextToggle = createContext();
export default CreateContextToggle;
