import React, { useContext } from 'react';

const FormInput = ({ ...option }) => {
  return <input {...option} />;
};

export default FormInput;
