import React from 'react';
import DashboardContain from '../Components/Dashboard';

const Dashboard = () => {
  return <DashboardContain />;
};

export default Dashboard;
