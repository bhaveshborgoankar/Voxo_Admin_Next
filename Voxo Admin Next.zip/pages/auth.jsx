import React from 'react';

const Auth = () => {
  return <div>Auth</div>;
};

export default Auth;
