import React from 'react';
import AddNewUsersContains from '../../../Components/Users/Add New User';

const AddNewUser = () => {
  return <AddNewUsersContains />;
};
export default AddNewUser;
