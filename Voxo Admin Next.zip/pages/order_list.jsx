import React from 'react';
// import OrderListContain from '../Components/Orders/OrderList';

const OrderList = () => {
  // return <OrderListContain />;
};

export default OrderList;
