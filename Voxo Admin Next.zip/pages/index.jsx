import { Fragment } from 'react';
import DashboardContain from '../Components/Dashboard';

export default function Home() {
  return <DashboardContain />;
}
