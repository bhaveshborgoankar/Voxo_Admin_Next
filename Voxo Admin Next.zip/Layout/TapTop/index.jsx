import React from 'react';
const TapTop = () => {
  return (
    <div className='tap-top'>
      <span className='lnr lnr-chevron-up'></span>
    </div>
  );
};
export default TapTop;
